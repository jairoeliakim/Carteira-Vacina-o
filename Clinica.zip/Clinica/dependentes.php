<?php 
require_once("./cabecalho.php");
?>
<h1>Servicos</h1>
<?php
require_once("./rodape.php");
?>