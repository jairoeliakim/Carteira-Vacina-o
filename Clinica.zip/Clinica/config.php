<?php
//variaveis do banco
$servidor = "localhost";
$usuario = "root";
$senha = "vertrigo";
$bd = "bd+vacinas";
$url = "https://localhost/carteiradevacina";

//VARIAVEIS GLOBAIS
$email = "jairo.costa@estudante.iftm.edu.br";
$endereço = "Av. Liria Terezinha Amaral - Dona Diva";
$cep = "38740-000";
$cel = "(34) 3131-3131";
$cel_link = "tel: 034 31313131";
$wpp = "31 994666217";
$wpp_link ="553194666217";
$facebook ="https://www.facebook.com/jairoeliakim/";
$facebook_link="https://www.facebook.com/jairoeliakim/";
$instagram="https://www.instagram.com/jairoeliakim/";
$instagram_link="https://www.instagram.com/jairoeliakim/";
$linkedin="https://br.linkedin.com/in/jairoeliakim";
$linkedin_link="https://br.linkedin.com/in/jairoeliakim";


$nome_empresa= "Carteira de Vacinas";


//DISPAROS AUTOMATIZADOS DE EMAIL
$enviar_total_email ="";

?>