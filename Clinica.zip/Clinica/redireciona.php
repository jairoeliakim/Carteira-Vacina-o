<?php 
require_once("./cabecalho.php");
?>
<h1>I'm Here!</h1>
<?php
require_once("./rodape.php");
?>