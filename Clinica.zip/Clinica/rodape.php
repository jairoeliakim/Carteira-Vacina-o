<footer id="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
        <a href="#"> <h6 class="text-light mt-3">Whatsapp</h6></a>
        <a href="#"> <h6 class="text-light mt-3">Contate-nos pelo chat</h6></a>
        <a href="#"> <h6 class="text-light mt-3">Contate nos pelo E-mail</h6></a>
        <a href="#"> <h6 class="text-light mt-3">Siga-nos no Instagram</h6></a>


        </div>
        <div class="col-md-4">
        <a href="#"> <h6 class="text-light mt-3">Institucional</h6></a>
        <a href="#"> <h6 class="text-light mt-3">Termos de uso</h6></a>
        <a href="#"> <h6 class="text-light mt-3">Politicas de Cookies</h6></a>
        <a href="#"> <h6 class="text-light mt-3">Politicas de privacidade</h6></a>
        <a href="#"> <h6 class="text-light mt-3">Central de atendimento</h6></a>






        </div>
        <div class="col-md-4">
        <a href="#"> <h6 class="text-light mt-3">Facebook</h6></a>
        <div class = "fb-page" data-href = "https://www.facebook.com/jairoeliakim" data-tabs = "timeline" data-width = "320" data-height = "180" data-small -header = "false" data-adapt-container-width = "true" data-hide-cover = "false" data-show-facepile = "true" ></div> 
        <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fjairoeliakim&tabs=timeline&width=320&height=180&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="320" height="180" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>

        </div>

      </div>

      
      
      <h3>Green</h3>
      <p>Et aut eum quis fuga eos sunt ipsa nihil. Labore corporis magni eligendi fuga maxime saepe commodi placeat.</p>
      <div class="social-links">
        <a href="#" class="whatsapp"><i class="bx bxl-whatsapp"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
      <div class = "fb-page" data-href = "https://www.facebook.com/jairoeliakim" data-tabs = "timeline" data-width = "320" data-height = "180" data-small -header = "false" data-adapt-container-width = "true" data-hide-cover = "false" data-show-facepile = "true" ></div> 

      <div class="copyright">
        &copy; Copyright <strong><span>Green</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/green-free-one-page-bootstrap-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
    


<!--Mapa Google Maps-->
<script type='text/javascript'
    src='https://maps.google.com/maps/api/js?key=AIzaSyDv7YRz1WWPhkr6aim8wEm4WDPBdk81z54'>
</script>


<!--Configurações do Google Maps-->
<script type='text/javascript'>
  function init_map(){
    var myOptions = {
        zoom:17,
        // Coordenadas do IFTM-18.955414964613126, -46.98291433103899
        center:new google.maps.LatLng(-18.955414964613126,-46.98291433103899),
        mapTypeId: google.maps.MapTypeId.ROADMAP
            };

            map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);
            marker = new google.maps.Marker({
                map: map,
                // Coordenadas do IFTM-18.955414964613126, -46.98291433103899
                position: new google.maps.LatLng(-18.955414964613126,-46.98291433103899),
                icon: './assets/imagens/logo_maps.png'
                    
            });

            infowindow = new google.maps.InfoWindow({
            content:'<strong>SuSon - Carteira de Vacinação</strong><br>Av. Líria Terezinha Lassi Capuano - <br>IFTM<br>Patrocínio/MG'

            });

            infowindow.open({
                shouldFocus: false,
                anchor: marker

            });   

            google.maps.event.addListener(marker, 'click', function(){
            infowindow.open(map,marker);
            
            });
                
        }
        google.maps.event.addDomListener(window, 'load', init_map);

</script>

  </footer><!-- End Footer -->